import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { AuthModule } from './auth/auth.module';
import { BitacoraModule } from './bitacora/bitacora.module';
import { ClientesModule } from './clientes/clientes.module';
import { ModulosModule } from './modulos/modulos.module';
import { S3Module } from './s3/s3.module';
import { MailModule } from './mail/mail.module';
import Joi from 'joi';


@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      validationSchema: Joi.object({
        DB_HOST: Joi.string().required(),
        DB_PORT: Joi.number().default(3306),
        DB_USER: Joi.string().required(),
        DB_PASSWORD: Joi.string().allow(''), // Puede estar vacío si no hay pass
        DB_DATABASE: Joi.string().required(),
        JWT_SECRET: Joi.string().required(),
        JWT_EXPIRES_IN: Joi.string().required(),
        JWT_CONFIRMACION: Joi.string().required(),
        ENDPOINT_URL: Joi.string().uri().required(),
        AWS_REGION: Joi.string().required(),
        AWS_ACCESS_KEY_ID: Joi.string().required(),
        AWS_SECRET_ACCESS_KEY: Joi.string().required(),
        AWS_S3_BUCKET: Joi.string().required(),
        UPLOAD_MAX_SIZE: Joi.string().required(),
        HOST: Joi.string().required(),
        SMTP: Joi.number().required(),
        E_MAIL: Joi.string().email().required(),
        MAIL_PASSWORD: Joi.string().required(),
        THROTTLE_DEFAULT_LIMIT: Joi.number().default(100),
        THROTTLE_DEFAULT_TTL_MS: Joi.number().default(60000),
        THROTTLE_LOGIN_LIMIT: Joi.number().default(5),
        THROTTLE_LOGIN_TTL_MS: Joi.number().default(60000),
        THROTTLE_PIN_LIMIT: Joi.number().default(5),
        THROTTLE_PIN_TTL_MS: Joi.number().default(60000),
        THROTTLE_VERIFY_LIMIT: Joi.number().default(3),
        THROTTLE_VERIFY_TTL_MS: Joi.number().default(60000),
        THROTTLE_RECUPERACION_LIMIT: Joi.number().default(2),
        THROTTLE_RECUPERACION_TTL_MS: Joi.number().default(60000),
        THROTTLE_RECUPERACION_CONFIRMACION_LIMIT: Joi.number().default(5),
        THROTTLE_RECUPERACION_CONFIRMACION_TTL_MS: Joi.number().default(60000),
        THROTTLE_REFRESH_LIMIT: Joi.number().default(5),
        THROTTLE_REFRESH_TTL_MS: Joi.number().default(60000),
        THROTTLE_LOGOUT_LIMIT: Joi.number().default(5),
        THROTTLE_LOGOUT_TTL_MS: Joi.number().default(60000),
      }),
    }),

    ThrottlerModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        throttlers: [
          {
            name: 'default',
            ttl: config.get<number>('THROTTLE_DEFAULT_TTL_MS', 60000),
            limit: config.get<number>('THROTTLE_DEFAULT_LIMIT', 100),
          },
        ],
      }),
    }),

    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'mysql',
        host: config.get<string>('DB_HOST'),
        port: config.get<number>('DB_PORT'),
        username: config.get<string>('DB_USER'),
        password: config.get<string>('DB_PASSWORD'),
        database: config.get<string>('DB_DATABASE'),
        autoLoadEntities: false,
        entities: [__dirname + '/entities/*{.ts,.js}'],
        synchronize: false, //Nunca poner en true
        dateStrings: false,
        timezone: 'Z',
        extra: {
          // Evita que bigint se devuelvan como string
          decimalNumbers: true,
        },
      }),
    }),

    AuthModule,

    BitacoraModule,

    ClientesModule,

    S3Module,

    MailModule,

    ModulosModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule {}
